# 🎲 Ludo Game

Ek pura browser-based Ludo game — HTML, CSS, aur JavaScript mein likha gaya. Koi library nahi, koi build step nahi. Seedha browser mein kholo aur khelo!

---

## 📁 Project Structure

```
ludo-game/
├── index.html          ← Main HTML file (entry point)
├── css/
│   └── style.css       ← Saari styling — board, tokens, animations, responsive
├── js/
│   ├── game.js         ← Game logic: moves, captures, turns, win detection
│   ├── board.js        ← Board aur token rendering
│   └── ui.js           ← Screens, player info panel, messages, scoreboard
├── data/
│   └── gameData.js     ← Static data: paths, safe spots, base positions, constants
└── README.md           ← Yeh file
```

---

## 🚀 Kaise Chalayein

1. Poora folder download karo ya clone karo.
2. `index.html` ko kisi bhi browser mein double-click karke kholo.
3. Khelo! Koi server ki zaroorat nahi.

---

## 🎮 Game Rules

| Rule | Detail |
|------|--------|
| Players | 2, 3, ya 4 |
| Token bahar nikalna | 6 aane par |
| Bonus turn | 6 aane par ek aur roll milti hai |
| Capture | Dusre player ke token pe land karo — woh ghar wapas |
| Safe spots ⭐ | In cells pe capture nahi hota |
| Home stretch | Colored corridor — sirf apna token ja sakta hai |
| Jeeto kaise | Saare 4 tokens center (🏠) tak pahunchao |

---

## 🛠️ Features

- ✅ 2 / 3 / 4 player support
- ✅ Animated dice roll
- ✅ Selectable tokens (pulse animation jab move possible ho)
- ✅ Safe spot protection
- ✅ Capture system with feedback message
- ✅ Bonus turn on rolling 6
- ✅ Home-stretch (colored corridor) validation
- ✅ Final scoreboard on game end
- ✅ Responsive design (mobile ke liye bhi kaam karta hai)
- ✅ Token number display (1–4)
- ✅ Player info cards with live token counts

---

## 🐛 Fixed Bugs (Original File Se)

| Bug | Fix |
|-----|-----|
| Finish boundary galat thi (`> 56`) | Correct boundary `>= 57` (52 main + 5 home stretch) |
| Home-stretch tokens capture ho sakte the | `position >= 52` wale tokens ko capture se bacha diya |
| Dice disabled nahi hoti thi roll ke baad | `.disabled` class add ki aur click block kiya |
| Token overlap pe koi visual distinction nahi | Token number (1–4) show hota hai |
| `endGame()` sirf ek function mein tha | `showWinner()` ko ui.js mein alag kiya — scoreboard bhi dikhata hai |
| Center cell me emoji nahi tha | 🏠 emoji add ki |

---

## 💡 Improvements Added

- Token number labels (1, 2, 3, 4) — saaf dikhta hai kon sa token kahan hai
- Base yard mein decorative circles — real Ludo board jaisi look
- Final scoreboard — game khatam hone par ranking dikhata hai
- Responsive CSS — mobile screen pe bhi board theek dikhta hai
- Better color gradients for tokens — 3D effect jaisi look
- `title` attribute on tokens — hover pe player naam dikhata hai

---

## 🎨 Technologies Used

- **HTML5** — structure
- **CSS3** — grid layout, animations, gradients, responsive design
- **Vanilla JavaScript** — pure JS, koi framework nahi

---

*Made with ❤️ — Khelo aur mazze karo!*
